package edu.du.sb1010_2;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Sb10102ApplicationTests {

    @Test
    void contextLoads() {
    }

}
