package edu.du.sb1010_2.chap07;

public interface Calculator {

	public long factorial(long num);

}
