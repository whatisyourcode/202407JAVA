package edu.du.sb1010_2.aop2;

public interface Greet {
    void greeting();
}
