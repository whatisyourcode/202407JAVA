package edu.du.chap17;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Chap17Application {

    public static void main(String[] args) {
        SpringApplication.run(Chap17Application.class, args);
    }

}
