package edu.du.chap17.service;

public class IdGenerationFailedException extends Exception {

	public IdGenerationFailedException(Throwable cause) {
		super(cause);
	}
}
