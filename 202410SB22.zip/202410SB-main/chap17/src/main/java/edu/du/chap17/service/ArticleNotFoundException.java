package edu.du.chap17.service;

public class ArticleNotFoundException extends Exception {

	public ArticleNotFoundException(String msg) {
		super(msg);
	}

}
