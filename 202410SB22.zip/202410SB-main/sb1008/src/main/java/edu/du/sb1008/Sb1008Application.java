package edu.du.sb1008;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Sb1008Application {

    public static void main(String[] args) {
        SpringApplication.run(Sb1008Application.class, args);
    }

}
