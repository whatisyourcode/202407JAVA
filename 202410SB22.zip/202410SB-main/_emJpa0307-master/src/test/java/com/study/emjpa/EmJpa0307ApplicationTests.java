package com.study.emjpa;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EmJpa0307ApplicationTests {

    @Test
    void contextLoads() {
    }

}
