package com.study.emjpa;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EmJpa0307Application {

    public static void main(String[] args) {
        SpringApplication.run(EmJpa0307Application.class, args);
    }

}
