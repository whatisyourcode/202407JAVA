package com.sky._sb0408;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Sb0409ApplicationTests {

    @Test
    void contextLoads() {
    }

}
