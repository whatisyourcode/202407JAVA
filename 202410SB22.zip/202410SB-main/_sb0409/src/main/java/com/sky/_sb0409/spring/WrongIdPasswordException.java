package com.sky._sb0409.spring;

public class WrongIdPasswordException extends RuntimeException {

}
