package com.sky._sb0409;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Sb0409Application {

    public static void main(String[] args) {
        SpringApplication.run(Sb0409Application.class, args);
    }

}
