package com.sky._sb0409.spring;

public class MemberNotFoundException extends RuntimeException {

}
