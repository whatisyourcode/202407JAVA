package edu.du.sb1011;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Sb1011Application {

    public static void main(String[] args) {
        SpringApplication.run(Sb1011Application.class, args);
    }

}
