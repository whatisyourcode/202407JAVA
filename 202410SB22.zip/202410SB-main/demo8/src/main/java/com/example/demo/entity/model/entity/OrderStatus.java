package com.example.demo.entity.model.entity;

public enum OrderStatus {

  ORDER, CANCEL

}
