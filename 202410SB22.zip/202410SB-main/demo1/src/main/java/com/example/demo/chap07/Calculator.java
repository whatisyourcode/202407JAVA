package com.example.demo.chap07;

public interface Calculator {

	public long factorial(long num);

}
