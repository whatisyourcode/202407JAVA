package edu.du.sb1010;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Sb1010ApplicationTests {

    @Test
    void contextLoads() {
    }

}
