package edu.du.sb1010;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Sb1010Application {

    public static void main(String[] args) {
        SpringApplication.run(Sb1010Application.class, args);
    }

}
