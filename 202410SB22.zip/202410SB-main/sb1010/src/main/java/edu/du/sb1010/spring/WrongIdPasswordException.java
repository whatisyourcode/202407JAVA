package edu.du.sb1010.spring;

public class WrongIdPasswordException extends RuntimeException {

}
