package edu.du.sb1010.spring;

public class MemberNotFoundException extends RuntimeException {

}
