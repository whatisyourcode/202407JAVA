package edu.du.sb1007;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Sb1007Application {

    public static void main(String[] args) {
        SpringApplication.run(Sb1007Application.class, args);
    }

}
