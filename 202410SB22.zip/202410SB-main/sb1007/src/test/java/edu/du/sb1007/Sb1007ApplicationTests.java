package edu.du.sb1007;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Sb1007ApplicationTests {

    @Test
    void contextLoads() {
    }

}
