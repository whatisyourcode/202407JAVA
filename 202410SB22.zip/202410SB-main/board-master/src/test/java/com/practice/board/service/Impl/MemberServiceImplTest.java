package com.practice.board.service.Impl;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class MemberServiceImplTest {

    @Test
    void joinTest() {

    }
}